struct Player {
  int code;
  char name[50];
  int age;
	int teamCode;
  char club[50];
  struct Player *next;
};